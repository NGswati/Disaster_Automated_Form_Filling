import pandas as pd


def word_match(question, sentence):
    # Rule #1
    return sum(1 for word in question.split() if word in sentence)


def rule_2(question, sentence):
    # Rule #2
    months = [
        "January",
        "February",
        "March",
        "April",
        "May",
        "June",
        "July",
        "August",
        "September",
        "October",
        "November",
        "December",
    ]
    if any(month in question for month in months) and any(day in sentence for day in ["today", "yesterday", "tomorrow", "last night"]):
        return 1
    return 0


def rule_3(question, sentence):
    # Rule #3
    if "kind" in question and any(word in sentence for word in ["call", "from"]):
        return 1
    return 0


def rule_4(question, sentence):
    # Rule #4
    if "name" in question and any(
        word in sentence for word in ["name", "call", "known"]
    ):
        return 1
    return 0


def rule_5(question, sentence):
    # Rule #5
    if any(phrase in question for phrase in ["name of", "name for"]):
        proper_noun = sentence.split()[-1]
        head_noun = proper_noun.split()[-1]
        if head_noun.lower() in question.lower():
            return 1
    return 0


def calculate_score(question, sentence):
    score = 0
    score += word_match(question, sentence)
    score += rule_2(question, sentence)
    score += rule_3(question, sentence)
    score += rule_4(question, sentence)
    score += rule_5(question, sentence)
    return score


def answer_what_questions(question,text):
    for q in question:
        question = q[1]
        answer_what=[]
        sorted_answer_what =[]
        for row in text:
            sentence = row
            score = calculate_score(question, sentence)
            answer_what.append([sentence,score])
        sorted_answer_what = sorted(answer_what, key=lambda x: x[1], reverse=True) 
        print(f"Question: {question}\n")
        if sorted_answer_what:
            for i in range(min(5, len(sorted_answer_what))):  
                print(f"Answer: {sorted_answer_what[i][0]} Score: {sorted_answer_what[i][1]}")
        else:
            print(" ")

input_path = "/Users/swati/Documents/DisasterAssesmentSystem/self/Answering/"

questions_file = open(input_path + "sample_question.csv")
questions_total = questions_file.read().splitlines()
# print(questions_total)
questions_data = []
for j in range(0, len(questions_total), 3):
    question_temp = []

    quesid = questions_total[j].split(":")[1].lstrip(" ")
    question_temp.append(quesid)
    ques = questions_total[j + 1].split(":")[1].lstrip(" ")
    question_temp.append(ques)
    questions_data.append(question_temp)
    # print(questions_data)

tweet_dict = open(input_path + "relevent.csv")

answer_what_questions(questions_data,tweet_dict)
