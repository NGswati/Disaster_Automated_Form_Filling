import pandas as pd
from nltk import sent_tokenize
from nltk.corpus import stopwords
from nltk.probability import FreqDist
from nltk.tokenize import word_tokenize
import re
from geotext import GeoText

df = pd.read_csv("/Users/swati/Documents/DisasterAssesmentSystem/Nepaltweets.csv")
text_data = " ".join(df["Tweet"].astype(str).tolist())

sentences = sent_tokenize(text_data)
words = word_tokenize(text_data.lower())

stop_words = set(stopwords.words("english"))
filtered_words = [word for word in words if word.isalnum() and word not in stop_words]

freq_dist = FreqDist(filtered_words)

main_disaster_keywords = [
    "earthquake",
    "flood",
    "fire",
    "hurricane",
    "tsunami",
    "tornado",
    "volcano",
    "cyclone",
    "wildfire",
    "drought",
    "avalanche",
    "landslide",
    "blizzard",
    "heatwave",
    "epidemic",
    "pandemic",
    "storm",
    "typhoon",
    "sinkhole",
    "mudslide",
    "forest fire",
    "hailstorm",
    "heat wave",
    "winter storm",
    "thunderstorm",
    "flash flood",
    "snowstorm",
    "heatstroke",
    "tsunami warning",
    "chemical spill",
    "radiation leak",
    "biological hazard",
    "power outage",
    "structural collapse",
    "explosion",
    "gas leak",
    "train derailment",
    "airplane crash",
    "shipwreck",
    "oil spill",
    "nuclear disaster",
    "terrorist attack",
]

main_disaster = None

for sentence in sentences:
    for keyword in main_disaster_keywords:
        if keyword in (sentence.lower() and freq_dist.keys() ):
            main_disaster = keyword
            break

locations = set()
for sentence in sentences:
    places = GeoText(sentence)
    locations.update(places.cities)

locations_with_disaster = [
    location
    for location in locations
    if any(keyword in text_data.lower() for keyword in main_disaster_keywords)
]
location_freq = {
    location: text_data.lower().count(location.lower())
    for location in locations_with_disaster
}

sorted_locations = sorted(location_freq.keys(), key=lambda x: location_freq[x], reverse=True)
locations = list(filter(None, locations))

magnitudes = []
for sentence in sentences:
    match = re.search(r"\b(\d+(\.\d+)?)\s*(Magnitude|Intensity)\b(?!\S)", sentence, re.IGNORECASE)
    if match:
        magnitude = float(match.group(1))
        if 0.0 <= magnitude <= 10.0:
            magnitudes.append(magnitude)

magnitude_freq = {
    magnitude: magnitudes.count(magnitude) for magnitude in set(magnitudes)
}

sorted_magnitudes = sorted(
    magnitude_freq.keys(), key=lambda x: magnitude_freq[x], reverse=True
)

# for sentence in sentences:
#     doc = nlp(sentence)
#     for ent in doc.ents:
#         if ent.label_ == "EVENT":
#             disasters.add(ent.text)
# disasters = list(disasters)
# print("Different types of disasters:", disasters)


occurrence_times = []
time_pattern = re.compile(r"\b(\d{1,2}:\d{2}(?:\s*[APMapm]{2,4})?)\b")

for sentence in sentences:
    match = time_pattern.search(sentence)
    if match:
        occurrence_times.append(match.group(1))

duration_patterns = [
    r"\b(\d+\s*(?:hours?|hrs?))\b",
    r"\b(\d+\s*(?:minutes?|mins?))\b",
    r"\b(\d+\s*(?:seconds?|secs?))\b",
]

durations = []

for sentence in sentences:
    for pattern in duration_patterns:
        match = re.search(pattern, sentence, re.IGNORECASE)
        if match:
            durations.append(match.group(1))

subsequent_events = []


for sentence in sentences:
    for keyword in main_disaster_keywords:
        if keyword in sentence.lower() and keyword != main_disaster:
            subsequent_events.append(keyword)

subsequent_events =list(set(subsequent_events))


weather_keywords = [
    "weather",
    "temperature",
    "rain",
    "precipitation",
    "drizzle",
    "downpour",
    "shower",
    "hail",
    "sleet",
    "snow",
    "blizzard",
    "storm",
    "thunderstorm",
    "lightning",
    "wind",
    "gust",
    "breeze",
    "hurricane",
    "tornado",
    "cyclone",
    "typhoon",
    "fog",
    "mist",
    "cloudy",
    "overcast",
    "clear",
    "sunny",
    "heat",
    "cold",
    "freeze",
    "thaw",
    "humidity",
    "dry",
    "wet",
    "muggy",
    "dew",
]

weather_conditions = []

for sentence in sentences:
    for keyword in weather_keywords:
        if keyword in sentence.lower():
            match = re.search(rf"\b{keyword}\b(.+?)[.?!]", sentence, re.IGNORECASE)
            if match:
                condition = match.group(1).strip()
                if condition:  
                    weather_conditions.append(condition)

# weather_conditions = []

# for sentence in sentences:
#     for keyword in weather_keywords:
#         if keyword in sentence.lower():
#             weather_conditions.append(sentence)
# weather_conditions = list(set(weather_conditions))


expected_keywords = [
    "expected",
    "anticipated",
    "predicted",
    "foreseen",
    "projected",
    "forecasted",
    "likely",
    "potential",
    "possible",
    "probable",
    "outlook",
    "development",
    "outcome",
]

expected_developments = []

for sentence in sentences:
    for keyword in expected_keywords:
        if keyword in sentence.lower():
            match = re.search(rf"\b{keyword}\b(.+?)[.?!]", sentence, re.IGNORECASE)
            if match:
                expected_development = match.group(1).strip()
                if expected_development:  
                    expected_developments.append(expected_development)


weather_forecasts = []

forecast_keywords = [
    "forecast",
    "prediction",
    "expectation",
    "prognosis",
    "outlook",
    "projection",
]

for sentence in sentences:
    for keyword in forecast_keywords:
        if keyword in sentence.lower():
            match = re.search(rf"\b{keyword}\b(.+?)[.?!]", sentence, re.IGNORECASE)
            if match:
                forecast = match.group(1).strip()
                if forecast:
                    weather_forecasts.append(forecast)


development_keywords = [
    "aftershocks",
    "water level rising",
    "water level falling",
    "flooding",
]

developments = {keyword: [] for keyword in development_keywords}

for sentence in sentences:
    for keyword in development_keywords:
        if keyword in sentence.lower():
            match = re.search(rf"\b{keyword}\b(.+?)[.?!]", sentence, re.IGNORECASE)
            if match:
                development = match.group(1).strip()
                if development:
                    developments[keyword].append(development)


questions_and_answers = {
    "What was the main disaster?": main_disaster,
    "Where the disaster occurred?": sorted_locations,
    "What was the magnitude?": sorted_magnitudes,
    "what was the Occurrence time?": occurrence_times,
    "what was the Duration?": durations,
    "what was the Subsequent events?": subsequent_events,
    "What is the Weather condition during the disaster?": weather_conditions,
    "what was the Expected development?": expected_developments,
    "What is the weather forecast?": weather_forecasts,
    "What are the developments?": developments,
}


for question, answer in questions_and_answers.items():
    print(f"Q: {question}")
    print(f"A: {answer}")
    print("=" * 30)
    disaster_file_path = f"filled_{sorted_locations[0]}_{main_disaster.lower()}.txt"
    with open(disaster_file_path, "a") as file:
        file.write(f"Q: {question}\n")
        file.write(f"A: {answer}\n")
        file.write("=" * 30 + "\n")
