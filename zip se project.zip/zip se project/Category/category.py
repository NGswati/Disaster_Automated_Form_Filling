import nltk
import json
from nltk.corpus import wordnet
from Category.disasters import disaster

# nltk.download('wordnet')  # Download the WordNet data
category = ['time', 'intensity', 'event', 'duration', 'population',
            'mud', 'thatched', 'masonry', 'reparable', 'market', 'household','injured', 'dead', 'missing',
            'storage', 'energy', 'utensils', 'damage', 'vaccination', 'diseases', 'emergency', 'cleaning', 'treatment',
            'toilets', 'seeds', 'harvest', 'fisheries', 'cattle', 'transportation', 'fuel', 'telecommunication',
            'help', 'shelter', 'education', "other"]

word_dicts = {}


# Synonyms
# Hyponyms
# Hypernyms
# Meronyms
# Holonyms

def get_word_relations(word):
    synsets = wordnet.synsets(word)

    if not synsets:
        print(f"No information found for the word '{word}'.")
        return set()

    # print(f"Word: {word}\n")

    # Synonyms
    final_set = set()
    final_set.add(word.lower())
    synonyms = set()
    for synset in synsets:
        for lemma in synset.lemmas():
            synonyms.add(lemma.name().replace('_', ' ').lower())
    # print(f"Synonyms: {', '.join(synonyms)}\n")
    final_set = final_set.union(synonyms)

    # Hyponyms
    hyponyms = set()
    for synset in synsets:
        hyponyms.update(
            set([lemma.name().replace('_', ' ').lower() for hypernym in synset.hyponyms() for lemma in
                 hypernym.lemmas()]))
    # print(f"Hyponyms: {', '.join(hyponyms)}\n")
    final_set = final_set.union(hyponyms)

    # Hypernyms
    hypernyms = set()
    for synset in synsets:
        hypernyms.update(
            set([lemma.name().replace('_', ' ').lower() for hypernym in synset.hypernyms() for lemma in
                 hypernym.lemmas()]))
    # print(f"Hypernyms: {', '.join(hypernyms)}\n")
    final_set = final_set.union(hypernyms)

    # Meronyms
    meronyms = set()
    for synset in synsets:
        meronyms.update(
            set([lemma.name().replace('_', ' ').lower() for part_meronym in synset.part_meronyms() for lemma in
                 part_meronym.lemmas()]))
    # print(f"Meronyms: {', '.join(meronyms)}\n")
    final_set = final_set.union(meronyms)

    # Holonyms
    holonyms = set()
    for synset in synsets:
        holonyms.update(
            set([lemma.name().replace('_', ' ').lower() for part_holonym in synset.part_holonyms() for lemma in
                 part_holonym.lemmas()]))
    # print(f"Holonyms: {', '.join(holonyms)}\n")
    final_set = final_set.union(holonyms)
    return final_set


for i in category:
    if i!="other":
        word_dicts[i] = list(get_word_relations(i))

with open('your_dict.json', 'w') as json_file:
    json.dump(word_dicts, json_file)
