import csv


def copy_next_n_rows(input_file, output_file, start_row, n):
    with open(input_file, 'r', newline='', encoding="utf8", errors='replace') as input_csv:
        with open(output_file, 'w', newline='', encoding="utf8", errors='replace') as output_csv:
            reader = csv.reader(input_csv)
            writer = csv.writer(output_csv)
            count = 0
            for row in reader:
                count += 1
                if start_row < count <= start_row + n:
                    writer.writerow(row)
                elif count > start_row + n:
                    break


# Usage
input_file = 'C:\\Users\91951\PycharmProjects\se project\\twitter data + test data\combined_final.csv'
output_file = 'preprocessed data nepal/seventh 15000/before.csv'
start_row = 90000
n = 12931
copy_next_n_rows(input_file, output_file, start_row, n)
