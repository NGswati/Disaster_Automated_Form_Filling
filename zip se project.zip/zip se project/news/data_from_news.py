import requests
import csv
import json


def put_in_file(data):
    list_of_data = data["articles"]
    data_file = open('data_file.csv', 'w')
    csv_writer = csv.writer(data_file)
    count = 0

    for des in list_of_data:
        if count == 0:
            # Writing headers of CSV file
            header = des.keys()
            csv_writer.writerow(header)
            count += 1

        # Writing data of CSV file
        csv_writer.writerow(des.values())
    data_file.close()


DISASTER = "nepal+earthquake+2015"
news_api_key = "3f72914668d04985aa9639d829941980"
url_news = f"https://newsapi.org/v2/everything?q={DISASTER}&apiKey={news_api_key}"

params = {
    "apiKey": news_api_key,
    "q": DISASTER,
    "language": "en",
    "sortBy": "relevancy",
    "page": 1

}

response = requests.get(url=url_news, params=params)
data = response.json()
# put_in_file(data)
text_data = ""
articles = data["articles"]
for dict in articles:
    if dict["title"] is not None:
        text_data += dict["title"]
    if dict["description"] is not None:
        text_data += dict["description"]
    if dict["content"] is not None:
        text_data += dict["content"]
# f = open("data_text.txt")
# with open('dataset_tweet-flash_2024-01-17_02-16-23-293.json', 'r', encoding='utf-8') as fcc_file:
#     fcc_data = json.load(fcc_file)
#
# # Open the output file with encoding='utf-8'
# with open("data_text.txt", "a", encoding='utf-8') as f:
#     for data_dict in fcc_data:
#         if data_dict["text"] is not None:
# f.write(text_data)
print(text_data)









