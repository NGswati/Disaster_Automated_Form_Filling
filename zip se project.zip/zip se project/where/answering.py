import nltk
import re
import spacy

# Load the English model
nlp = spacy.load("en_core_web_sm")

# nltk.download('stopwords')
from nltk.corpus import stopwords

stop_words = set(stopwords.words('english') + ['rt'])


def find_locations(text):
    doc = nlp(text)
    # Extract locations
    locations = [ent.text for ent in doc.ents if ent.label_ == "GPE"]
    return locations


# def find_highest_frequency(locations):
#     # Create a dictionary to store frequencies of lowercase locations
#     frequency_dict = {}
#
#     # Convert locations to lowercase and count frequencies
#     for loc in locations:
#         loc_lower = loc.lower()
#         frequency_dict[loc_lower] = frequency_dict.get(loc_lower, 0) + 1
#
#     # Find the location with the highest frequency
#     max_frequency = max(frequency_dict.values())
#     most_frequent_locations = [loc for loc, freq in frequency_dict.items() if freq == max_frequency]
#     return most_frequent_locations[0] if most_frequent_locations else None


def find_most_frequent_location(file):
    location_frequency = {}
    with open(file, 'r', encoding='utf-8') as f:
        lines = f.readlines()
        for line in lines:
            # Find locations in the current line
            locations = find_locations(line)
            if locations:
                for loc in locations:
                    loc_lower = loc.lower()
                    location_frequency[loc_lower] = location_frequency.get(loc_lower, 0) + 1

    # Find the most frequent location
    max_frequency_location = max(location_frequency, key=location_frequency.get) if location_frequency else None
    return max_frequency_location


def remove_duplicates(file):
    # Read existing lines from the file
    with open(file, "r") as fi:
        lines = fi.readlines()

    # Use a set to remove duplicates
    lines = set(lines)

    # Write back to the file without duplicates
    with open(file, "w") as fi:
        for line in lines:
            fi.write(line)


def empty_file(file_path):
    with open(file_path, "w") as ff:
        ff.truncate(0)


def add_category(test_file, file, cat):
    with open(test_file, 'r', encoding='utf-8') as fi:
        lines = fi.readlines()
    with open(file, 'a', encoding='utf-8') as fi:
        for line in lines:
            tweet, category = line.strip().split(',', 1)
            if category.strip() == cat:
                fi.write(tweet.strip() + '\n')
    remove_duplicates(file)


def remove_stopwords(text):
    # Split the text into words
    words = text.split()
    # Remove stopwords
    filtered_words = [word for word in words if word.lower() not in stop_words]
    # Join the filtered words back into a sentence
    filtered_text = ' '.join(filtered_words)
    return filtered_text


def makeLower(text):
    text = text.lower()
    return text


def remove_punctuation(text):
    # Define a regex pattern to match all punctuation marks
    punctuation_pattern = r'[!\"#$%&\'()*+,\-/:;<=>?@\[\\\]^`{|}~_]'  # Matches specific punctuation marks and underscore
    # Use the sub() function to replace punctuations with an empty string
    return re.sub(punctuation_pattern, '', text)


with open("where questions.csv", "r") as f:
    questions = f.readlines()

category = ['time', 'intensity', 'event', 'duration', 'population',
            'mud', 'thatched', 'masonry', 'reparable', 'market', 'household', 'injured', 'dead', 'missing',
            'storage', 'energy', 'utensils', 'damage', 'vaccination', 'diseases', 'emergency', 'cleaning',
            'treatment', 'toilets', 'seeds', 'harvest', 'fisheries', 'cattle', 'transportation', 'fuel',
            'telecommunication',
            'help', 'shelter', 'education']


def affected_location_answering(ques):
    words = ques.split(' ')
    for word in words:
        if word == "most":
            answer = find_most_frequent_location(
                "C:\\Users\91951\PycharmProjects\where questions\locations\combined_files.txt")
            print(answer)
        elif word == "cities" or word == "urban":
            answer = find_cities("C:\\Users\91951\PycharmProjects\where questions\locations\combined_files.txt")
        elif word == "districts" or word == "villages" or word == "sectors":
            answer = find_districts("C:\\Users\91951\PycharmProjects\where questions\locations\combined_files.txt")

def find_cities(path):

def find_districts(path):


categories_matching = []
for ques in questions:
    print(ques)
    ques = remove_punctuation(ques)
    ques = remove_stopwords(ques)
    ques = makeLower(ques)
    words = ques.split(' ')
    for word in words:
        if word.lower() in category:
            if word.lower() == "affected":
                affected_location_answering(ques)
            categories_matching.append(word.lower())
            add_category("test.csv", "category_wise_data_tweet.csv", word.lower())
    most_frequent_location = find_most_frequent_location("category_wise_data_tweet.csv")

    # Print the line where the most frequent location occurs
    if most_frequent_location:
        with open("category_wise_data_tweet.csv", 'r', encoding='utf-8') as f:
            lines = f.readlines()
            for line in lines:
                if most_frequent_location in line.lower():
                    print("Most frequent location:", most_frequent_location)
                    print("Line:", line.strip())
    else:
        print("No location found in this category")

    empty_file("category_wise_data_tweet.csv")
