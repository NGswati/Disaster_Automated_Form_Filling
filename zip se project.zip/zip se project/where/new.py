import spacy
from geopy.geocoders import Nominatim

# Load spaCy model
nlp = spacy.load("en_core_web_sm")

# Initialize Nominatim geocoder
geolocator = Nominatim(user_agent="my-custom-agent")


# Function to read locations from file
def read_locations_from_file(file_path):
    with open(file_path, "r") as f:
        locations = f.readlines()
    return [location.strip() for location in locations]


# Function to differentiate between regions, cities, and countries
def differentiate_locations(locations):
    regions = []
    cities = []
    countries = []

    for location in locations:
        # Geocode the location to get detailed information
        location_info = geolocator.geocode(location)
        if location_info:
            # Extract country, state/region, and city (if available)
            country = location_info.raw.get('address', {}).get('country', 'N/A')
            region = location_info.raw.get('address', {}).get('state', 'N/A')
            city = location_info.raw.get('address', {}).get('city', 'N/A')

            # Add to respective lists
            if city != 'N/A':
                cities.append(city)
            elif region != 'N/A':
                regions.append(region)
            elif country != 'N/A':
                countries.append(country)

    return regions, cities, countries


# File path containing locations
file_path = "C:\\Users\91951\PycharmProjects\se project\where\combined_files.txt"

# Read locations from file
locations = read_locations_from_file(file_path)

# Differentiate between regions, cities, and countries
regions, cities, countries = differentiate_locations(locations)

# Print the results
print("Regions:", regions)
print("Cities:", cities)
print("Countries:", countries)
