import re
from nltk.corpus import stopwords
import nltk
import spacy

# essential entity models downloads
nltk.downloader.download('maxent_ne_chunker')
nltk.downloader.download('words')
nltk.downloader.download('treebank')
nltk.downloader.download('maxent_treebank_pos_tagger')
nltk.downloader.download('punkt')
nltk.download('averaged_perceptron_tagger')
import locationtagger

# Download NLTK stopwords list (only required once)
import nltk
from functools import partial

# partial is used to freeze function

nltk.download('stopwords')

# Get the English stopwords list
stop_words = set(stopwords.words('english') + ['rt'])
from nltk.tokenize import word_tokenize


# Download nltk data if not already downloaded
nltk.download('punkt')


def tokenize_and_remove_short_words(text):
    # Tokenize the text
    tokens = word_tokenize(text)

    # Filter out words with 2 or 3 letters
    filtered_tokens = ' '.join(tokens)
    return filtered_tokens


def removeUnicode(text):
    """ Removes unicode strings like "\u002c" and "x96" """
    text = re.sub(r'(\\u[0-9A-Fa-f]+)', r'', text)
    text = re.sub(r'[^\x00-\x7f]', r'', text)
    return text


def removeHashtagInFrontOfWord(text):
    place_entity = locationtagger.find_locations(text=text)
    if len(place_entity.countries) != 0 or len(place_entity.regions) != 0 or len(place_entity.cities) != 0:
        with open("locations.txt", "a") as f:
            for coun in place_entity.countries:
                f.write(coun)
                f.write("\n")
            for reg in place_entity.regions:
                f.write(reg)
                f.write("\n")
            for city in place_entity.cities:
                f.write(city)
                f.write("\n")

    regexp = r'#\S+'
    res = re.sub(regexp, '', text)
    return res


def removeatUserfromWord(text):
    regexp = r'@\S+'
    res = re.sub(regexp, '', text)
    return res


def removeLinks(text):
    regexp = r'http\S+|www\S+'
    res = re.sub(regexp, '', text)
    return res


def removeEmoji(text):
    regexp = r'_\S+'
    res = re.sub(regexp, '', text)
    return res


def removeEmoticons(text):
    text = re.sub(
        ':\)|;\)|:-\)|\(-:|:-D|=D|:P|xD|X-p|\^\^|:-*|\^\.\^|\^\-\^|\^\_\^|\,-\)|\)-:|:\'\(|:\(|:-\(|:\S|T\.T|\.\_\.|:<|:-\S|:-<|\*\-\*|:O|=O|=\-O|O\.o|XO|O\_O|:-\@|=/|:/|X\-\(|>\.<|>=\(|D:',
        '', text)
    return text


def remove_extra_spaces(text):
    return ' '.join(text.split())


def replaceMultiExclamationMark(text):
    # Replace multiple occurrences of exclamation marks or asterisks with a single space
    text = re.sub(r"([!*])\1+", ' ', text)
    return text


def replaceMultiQuestionMark(text):
    text = re.sub(r"(\?)\1+", ' ', text)
    return text


def replaceMultiStopMark(text):
    text = re.sub(r"(\.)\1+", ' ', text)
    return text


def remove_stopwords(text):
    # Split the text into words
    words = text.split()
    # Remove stopwords
    filtered_words = [word for word in words if word.lower() not in stop_words]
    # Join the filtered words back into a sentence
    filtered_text = ' '.join(filtered_words)
    return filtered_text


def remove_quotes(text):
    return re.sub(r'"', '', text)


def makeLower(text):
    text = text.lower()
    return text


def remove_punctuation(text):
    # Define a regex pattern to match all punctuation marks
    punctuation_pattern = r'[!\"#$%&\'()*+,\-/:;<=>?@\[\\\]^`{|}~_]'  # Matches specific punctuation marks and underscore
    # Use the sub() function to replace punctuations with an empty string
    return re.sub(punctuation_pattern, '', text)


file_ = open("temp.csv", "r", encoding="utf8", errors='replace').read() # ENTER FILE NAME HERE "combined_final.csv"
with open('slang.txt') as file:
    slang_map = dict(map(str.strip, line.partition('\t')[::2])
                     for line in file if line.strip())

slang_words = sorted(slang_map, key=len, reverse=True)  # longest first for regex
regex = re.compile(r"\b({})\b".format("|".join(map(re.escape, slang_words))))
replaceSlang = partial(regex.sub, lambda m: slang_map[m.group(1)])

# List of text processing functions
processing_functions = [
    removeUnicode,
    removeHashtagInFrontOfWord,
    makeLower,
    removeLinks,
    removeEmoji,
    removeatUserfromWord,
    removeEmoticons,
    replaceMultiStopMark,
    replaceMultiExclamationMark,
    replaceMultiQuestionMark,
    remove_extra_spaces,
    remove_quotes,
    remove_punctuation,
    tokenize_and_remove_short_words,
    remove_stopwords

]

# Iterate through each line in the input
processed_lines = []
for line in file_.split('\n'):
    # Apply each processing function to the line sequentially
    for func in processing_functions:
        # line = line.lower()
        line = func(line)
    # Print the processed line
    processed_lines.append(line)

with open("temp.csv", "w", encoding="utf8", errors='replace') as file: # ENTER FULL FILE NAME HERE ALSO
    for line in processed_lines:
        file.write(line + '\n')
