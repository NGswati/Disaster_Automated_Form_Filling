import nltk
import json
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from collections import Counter
import pandas as pd

# Load word dictionaries
with open('C:\\Users\91951\PycharmProjects\se project\Category\your_dict.json', 'r') as json_file:
    word_dicts = json.load(json_file)

# Read the DataFrame
df = pd.read_csv('C:\\Users\91951\PycharmProjects\se project\\twitter data + test data\\temp.csv')


# Tokenize and preprocess function
def tokenize_and_preprocess(text):
    stop_words = set(stopwords.words('english'))
    tokens = word_tokenize(text.lower())
    tokens = [token for token in tokens if token.isalnum() and token not in stop_words]
    return tokens


# Calculate word frequencies function
def calculate_word_frequencies(tokens, category_words):
    word_freq = Counter(tokens)
    category_freq = sum(word_freq[word] for word in category_words)
    return category_freq


# Categorize tweets based on word frequencies
def categorize_tweet(tweet):
    tokens = tokenize_and_preprocess(tweet)
    category_scores = {}

    for category, category_words in word_dicts.items():
        category_scores[category] = calculate_word_frequencies(tokens, category_words)

    # If all category frequencies are 0, classify as "other"
    if all(freq == 0 for freq in category_scores.values()):
        return "other"

    max_category = max(category_scores, key=category_scores.get)
    return max_category


# Apply categorization to each tweet in the DataFrame
df['category'] = df['text'].head(20000).apply(categorize_tweet)

# Save the categorized tweets to a new CSV file
df.to_csv("test.csv", index=False)
