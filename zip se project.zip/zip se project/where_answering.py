# import spacy
# import locationtagger
# from collections import Counter
#
# # Load the English language model for spaCy
# nlp = spacy.load("en_core_web_sm")
#
#
# # Sample function to read locations from a file
# def read(file_path):
#     with open(file_path, "r") as f:
#         locations = f.readlines()
#     # Remove duplicates and newline characters
#     locations = list([location.rstrip('\n').capitalize() for location in locations])
#     return locations
#
#
# # Function to extract locations using location tagger
# def extract_locations(locations):
#     place_entity = locationtagger.find_locations(text=' '.join(locations))
#     return place_entity
#
#
# # Define the file path containing locations
# combined_file = 'C:\\Users\91951\PycharmProjects\se project\where\combined_files.txt'
# locations = read(combined_file)
#
# # Extract locations using location tagger
# place_entity = extract_locations(locations)
#
# # Collect cities, countries, and regions
# cities = place_entity.cities
# countries = place_entity.countries
# regions = place_entity.regions
#
# # Print the most frequent country
# country_counts = Counter(countries)
# most_frequent_country = country_counts.most_common(1)
# print("Most frequent country:", most_frequent_country[0][0])
# print("Frequency:", most_frequent_country[0][1])
import geonamescache

gc = geonamescache.GeonamesCache()

# gets nested dictionary for countries
countries = gc.get_countries()

# gets nested dictionary for cities
cities = gc.get_cities()