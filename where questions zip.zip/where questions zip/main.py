file = "QuestionSet.csv"
write_file = "where questions.csv"
number = 1
write_ = open(write_file, "a")
with open(file, "r") as f:
    qs = f.readlines()

for ques in qs:
    words = ques.split(' ')
    if len(words) > 3 and (words[1] == "where" or words[1] == "Where"):
        write_.write(ques.split(': ')[1])
        number += 1
