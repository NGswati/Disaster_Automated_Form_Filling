import csv


def remove_empty_lines(input_file, output_file):
    with open(input_file, 'r', newline='') as infile:
        reader = csv.reader(infile)
        data = [row for row in reader if any(row)]

    with open(output_file, 'w', newline='') as outfile:
        writer = csv.writer(outfile)
        writer.writerows(data)


# Example usage:
input_file = 'twitter.csv'
output_file = 'output.csv'
remove_empty_lines(input_file, output_file)
print("Empty lines removed successfully.")
