import spacy
from locationtagger import LocationTagger

# Load the English language model for spacy
nlp = spacy.load("en_core_web_sm")

# Initialize the LocationTagger
location_tagger = LocationTagger()


# Function to extract locations from text
def extract_locations(text):
    doc = nlp(text)
    return location_tagger.extract_locations(doc)


# Function to process combined files and extract locations
def process_combined_files(file_name):
    cities = set()
    districts = set()
    countries = set()

    with open(file_name, 'r') as file:
        text = file.read()
        locations = extract_locations(text)
        for loc_type, loc_name in locations:
            if loc_type == "city":
                cities.add(loc_name)
            elif loc_type == "district":
                districts.add(loc_name)
            elif loc_type == "country":
                countries.add(loc_name)

    return cities, districts, countries


# Process combined file
combined_file = 'combined_files.txt'
cities, districts, countries = process_combined_files(combined_file)

# Print results
print("Cities:", cities)
print("Districts:", districts)
print("Countries:", countries)
