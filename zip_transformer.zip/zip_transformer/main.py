from transformers import pipeline

# Load the question answering pipeline with different parameters
qa_pipeline = pipeline(
    "question-answering",
    model="bert-large-uncased-whole-word-masking-finetuned-squad",
    max_answer_len=300,
)

input_path = "C:\\Users\91951\PycharmProjects\\transformer\\"

questions_data = []
with open(input_path + "what and where.csv", encoding="utf-8", errors="replace") as questions_file:
    lines = questions_file.readlines()
    for i in range(0, len(lines), 3):
        quesid = lines[i].split(":")[1].strip()
        ques = lines[i + 1].split(":")[1].strip()
        questions_data.append((quesid, ques))

with open(input_path + "test.csv", encoding="utf-8", errors="replace") as tweet_file:
    context = tweet_file.read()

for quesid, question in questions_data:
    answer = qa_pipeline(question=question, context=context)
    print("Question:", question)
    print("Answer:", answer["answer"])
