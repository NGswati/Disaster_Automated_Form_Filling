def split_file(input_file, output_prefix, num_files=50):
    with open(input_file, 'r') as f:
        lines = f.readlines()

    total_lines = len(lines)
    lines_per_file = total_lines // num_files
    remainder = total_lines % num_files

    start = 0
    for i in range(num_files):
        filename = f"{output_prefix}_{i}.txt"
        with open(filename, 'w') as f:
            chunk_size = lines_per_file + 1 if i < remainder else lines_per_file
            f.write(''.join(lines[start:start + chunk_size]))
            start += chunk_size


if __name__ == "__main__":
    input_file = "locations.txt"
    output_prefix = "output_file"  # Prefix for output files
    split_file(input_file, output_prefix)
