import locationtagger
from time import sleep

output_prefix = "output_file"

# Initialize empty lists to store regions, cities, countries, and their combinations
regions_list = []
cities_list = []
countries_list = []
other_list = []

for i in range(50):
    with open(f"{output_prefix}_{i}.txt", "r") as f:
        lines = f.readlines()

    # Concatenate lines and capitalize
    lines = [line.capitalize() for line in lines]
    text = ' '.join(lines)

    # Extract location entities
    place_entity = locationtagger.find_locations(text=text)

    # Add entities to respective lists
    regions_list = regions_list + place_entity.regions
    regions_extra = place_entity.other_regions
    for region in regions_extra:
        if region not in regions_list:
            regions_list.append(region)

    cities_list = cities_list + place_entity.cities
    countries_list = countries_list + place_entity.countries
    countries_extra = place_entity.other_countries
    for coun in countries_extra:
        if coun not in countries_list:
            countries_list.append(coun)
    other_list = other_list + place_entity.other
    sleep(3)
    lines = []


def write_list_to_file(file_name, data_list):
    with open(file_name, 'w', encoding="utf-8", errors="replace") as f:
        for item in data_list:
            f.write("%s\n" % item)


write_list_to_file("regions.txt", regions_list)
write_list_to_file("cities.txt", cities_list)
write_list_to_file("countries.txt", countries_list)
write_list_to_file("other.txt", other_list)



