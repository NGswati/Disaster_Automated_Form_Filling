def find_most_frequent_location(file):
    location_frequency = {}
    with open(file, 'r', encoding="utf-8", errors="replace") as f:
        locations = f.readlines()
        if locations:
            for loc in locations:
                loc_lower = loc.strip().lower()  # Strip newline characters and convert to lowercase
                location_frequency[loc_lower] = location_frequency.get(loc_lower, 0) + 1

    # Find the most frequent locations
    sorted_locations = sorted(location_frequency.items(), key=lambda x: x[1], reverse=True)
    top_7_locations = [loc[0] for loc in sorted_locations[:7]]
    return top_7_locations

# Collect top 7 frequent locations for each category
top_7_countries = find_most_frequent_location("countries.txt")
top_7_regions = find_most_frequent_location("regions.txt")
top_7_cities = find_most_frequent_location("cities.txt")
top_7_others = find_most_frequent_location("other.txt")

# Print top 7 most frequent locations for each category
print("Top 7 most frequent countries:")
print(top_7_countries)
print("Top 7 most frequent regions:")
print(top_7_regions)
print("Top 7 most frequent cities:")
print(top_7_cities)
print("Top 7 most frequent others:")
print(top_7_others)
